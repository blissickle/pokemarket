# Pokémon Card Discord Bot

A Discord bot that publishes Pokémon card sets from TCGdex, links matching posts, and displays PriceCharting estimates when API access is configured.

## Run & Operate

- `pnpm --filter @workspace/scripts run pokemon-bot` — run the Discord bot
- `pnpm run typecheck` — full typecheck across all packages
- Required secret: `DISCORD_BOT_TOKEN`
- Optional price secret: `PRICECHARTING_API_TOKEN` (paid PriceCharting API access)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Discord REST API and Gateway
- TCGdex REST API for English, Japanese, Simplified Chinese, and Traditional Chinese card data
- PriceCharting REST API for ungraded USD values

## Where things live

- `scripts/src/pokemon-bot/` — bot commands, card lookup, publishing, prices, and state
- `scripts/data/pokemon-discord-bot-state.json` — local server configuration and tracked posts; excluded from Git

## Architecture decisions

- TCGdex supplies card and set metadata; language codes are `ja`, `zh-cn`, and `zh-tw`.
- PriceCharting is optional because its API requires a paid subscription and token.
- PriceCharting's ungraded value is stored in USD; posts with unresolved products are retried weekly.

## Product

- `/set` publishes cards from a selected localized set.
- `/locate` searches configured channels and threads for matching cards.
- `/locaterange` manages the channels scanned by `/locate`.

## User preferences

_No additional preferences recorded._

## Gotchas

- Discord requires the privileged Message Content Intent for channel-history search.
- Slash-command names are lowercase, so the range command is `/locaterange`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
