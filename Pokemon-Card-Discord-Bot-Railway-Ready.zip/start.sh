#!/bin/sh
set -eu
exec pnpm --filter @workspace/scripts run pokemon-bot
