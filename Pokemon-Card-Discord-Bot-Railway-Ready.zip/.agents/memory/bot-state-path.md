---
name: Bot state path
description: Package working-directory behavior and safe migration of persistent bot state.
---

Resolve persistent state from the module or package location rather than from `process.cwd()` when starting a service through a filtered pnpm script.

**Why:** `pnpm --filter @workspace/scripts run ...` runs with `scripts/` as the working directory. Resolving `scripts/data/...` from there points at `scripts/scripts/data/...` and can strand server settings when the path changes.

**How to apply:** Anchor future bot data paths to `import.meta.url` or the package root. If correcting an existing path, read the legacy file and migrate it without deleting the source.