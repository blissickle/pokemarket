# Railway deployment

This project is prepared to run the Pokémon Discord bot on Railway.

## Deploy from GitHub

Upload the **contents of this repository** to GitHub. Do not upload the ZIP file itself as the repository contents.

Railway should detect the Node/pnpm project from `package.json` and `pnpm-lock.yaml`.

The repository includes:

- `start.sh` — starts the Discord bot
- `railway.toml` — tells Railway to use Railpack and `./start.sh`
- root `package.json` — includes a `start` script

## Railway variables

Add:

```text
DISCORD_BOT_TOKEN=your Discord bot token
```

Optional:

```text
PRICECHARTING_API_TOKEN=your PriceCharting API token
```

If you add a Railway Volume mounted at `/data`, also add:

```text
BOT_STATE_DIR=/data
```

Using a volume keeps the bot's JSON state across redeployments/restarts. Without a volume, the bot can run, but local state should not be treated as permanent storage.

## Start command

The included Railway configuration uses:

```text
./start.sh
```

which runs:

```text
pnpm --filter @workspace/scripts run pokemon-bot
```
