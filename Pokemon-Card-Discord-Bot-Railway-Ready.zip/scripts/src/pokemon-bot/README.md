# Pokémon set Discord bot

The bot posts Pokémon card sets from TCGdex, including Japanese and Simplified/Traditional Chinese sets, searches configured Discord channels for matching posts, and adds prices from PriceCharting when API access is configured.

## Start it

1. Create a Discord application and bot in the [Discord Developer Portal](https://discord.com/developers/applications).
2. Under **Bot**, enable the privileged **Message Content Intent**. The bot reads configured channel history to locate matching cards.
3. Add `DISCORD_BOT_TOKEN` as a Replit Secret.
4. Start the **Pokémon Discord Bot** workflow. It registers slash commands and prints a server-install link to the workflow log.
5. Open that link, select the server, and install the bot.
6. Grant it View Channel, Send Messages, Embed Links, Read Message History, Create Public Threads, and Send Messages in Threads in the channels where it will post/search.
7. In the server, use `/locaterange add` to choose channels the bot should search.

The invite URL uses `scope=bot applications.commands`; its application ID is read from the bot token/API when the service starts. A template, if you need to build the link yourself, is:

`https://discord.com/oauth2/authorize?client_id=YOUR_APPLICATION_ID&permissions=309237731328&scope=bot%20applications.commands`

## Commands

- `/set set:<autocomplete>` — choose a set shown as `English | Stellar Crown` or `Chinese | <localized set name>`. The bot then asks which text or forum channel to use. A text channel gets one thread for the set with one card embed per message; a forum gets one post per card, titled with the card name and number.
- `/locate name:<card name> [set:<autocomplete>]` — search configured channels and their public threads, then return links to matches.
- `/locaterange add channel:<channel>` — add a text/forum channel to the search range.
- `/locaterange remove channel:<channel>` — remove a channel.
- `/locaterange list` — show configured channels.

After publishing a set, the bot scans the configured range and adds links between matching card/set posts. Tracked PriceCharting embeds are refreshed daily.

## PriceCharting price data

PriceCharting requires a paid subscription and an API token. Add the token as the `PRICECHARTING_API_TOKEN` Replit Secret. Card prices use PriceCharting's ungraded (`loose-price`) value, returned in USD. Some cards may not have a matching listing or a reported price; card/set publishing still works when prices are unavailable.

PriceCharting's API token is tied to the guide and access purchased with the subscription. A rejected token or missing paid API access leaves card/set publishing available but disables price lookups.

TCGdex language codes are `ja` for Japanese, `zh-cn` for Simplified Chinese, and `zh-tw` for Traditional Chinese.

## Development

- `pnpm --filter @workspace/scripts run pokemon-bot` — start the bot process
- `pnpm --filter @workspace/scripts run typecheck` — typecheck the bot and scripts package

Runtime settings and tracked posts are saved locally in `scripts/data/pokemon-discord-bot-state.json` and excluded from Git.