import { BotCommands } from "./commands.js";
import { DiscordRest } from "./discord-rest.js";
import type { DiscordInteraction } from "./types.js";

const INTENTS = 1 | 512 | 32768; // Guilds, Guild Messages, Message Content

type GatewayPayload = {
  op: number;
  d?: any;
  s?: number | null;
  t?: string;
};

type BotApplication = { id: string; name?: string };

export class DiscordGateway {
  private socket?: WebSocket;
  private heartbeatTimer?: ReturnType<typeof setInterval>;
  private reconnectTimer?: ReturnType<typeof setTimeout>;
  private gatewayUrl = "wss://gateway.discord.gg";
  private resumeUrl?: string;
  private sequence: number | null = null;
  private sessionId?: string;
  private applicationId?: string;
  private heartbeatInterval = 0;
  private heartbeatAcknowledged = true;
  private stopping = false;
  private reconnecting = false;
  private readyResolver?: () => void;

  constructor(
    private readonly token: string,
    private readonly rest: DiscordRest,
    private readonly commands: BotCommands,
  ) {}

  async start(): Promise<string> {
    const gateway = await this.rest.request<{ url: string }>("/gateway/bot");
    if (!gateway.url) throw new Error("Discord did not return a Gateway URL.");
    this.gatewayUrl = gateway.url;

    try {
      const app = await this.rest.request<BotApplication>("/oauth2/applications/@me");
      this.applicationId = app.id;
    } catch {
      this.applicationId = decodeApplicationId(this.token);
    }
    if (!this.applicationId) {
      throw new Error("Could not determine the Discord application ID from the bot token.");
    }

    await this.registerCommands();
    const ready = new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.readyResolver = undefined;
        reject(new Error("Discord Gateway did not send READY within 30 seconds."));
      }, 30_000);
      this.readyResolver = () => {
        clearTimeout(timeout);
        this.readyResolver = undefined;
        resolve();
      };
    });
    this.openSocket(this.resumeUrl ?? this.gatewayUrl);
    try {
      await ready;
      return this.applicationId;
    } catch (error) {
      this.stop();
      throw error;
    }
  }

  stop(): void {
    this.stopping = true;
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.socket?.close(1000, "Bot shutdown");
  }

  private async registerCommands(): Promise<void> {
    const commands = [
      {
        name: "set",
        description: "Post every card in a Pokémon set",
        options: [
          {
            type: 3,
            name: "set",
            description: "Choose a language and set",
            required: true,
            autocomplete: true,
          },
        ],
      },
      {
        name: "locate",
        description: "Find cards with this name in configured channels",
        options: [
          { type: 3, name: "name", description: "Card name to find", required: true },
          {
            type: 3,
            name: "set",
            description: "Limit matches to a Pokémon set",
            required: false,
            autocomplete: true,
          },
        ],
      },
      {
        name: "locaterange",
        description: "Choose where card searches look",
        default_member_permissions: "32",
        options: [
          {
            type: 1,
            name: "add",
            description: "Add a text or forum channel to the search range",
            options: [
              { type: 7, name: "channel", description: "Channel to search", required: true, channel_types: [0, 15] },
            ],
          },
          {
            type: 1,
            name: "remove",
            description: "Remove a channel from the search range",
            options: [
              { type: 7, name: "channel", description: "Channel to remove", required: true, channel_types: [0, 15] },
            ],
          },
          { type: 1, name: "list", description: "Show channels in the search range" },
        ],
      },
    ];
    await this.rest.request(`/applications/${this.applicationId}/commands`, {
      method: "PUT",
      body: commands,
    });
  }

  private openSocket(url: string): void {
    if (this.stopping || this.reconnecting) return;
    this.reconnecting = true;
    const socketUrl = `${url}${url.includes("?") ? "&" : "?"}v=10&encoding=json`;
    const socket = new WebSocket(socketUrl);
    this.socket = socket;

    socket.addEventListener("open", () => {
      this.reconnecting = false;
    });
    socket.addEventListener("message", (event) => {
      try {
        const payload = JSON.parse(String(event.data)) as GatewayPayload;
        if (payload.s !== null && payload.s !== undefined) this.sequence = payload.s;
        void this.handlePayload(payload);
      } catch (error) {
        console.error(`[gateway] Could not parse a gateway message: ${(error as Error).message}`);
      }
    });
    socket.addEventListener("close", (event) => {
      this.reconnecting = false;
      if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = undefined;
      console.warn(
        `[gateway] Connection closed (code ${event.code}` +
          `${event.reason ? `, reason: ${event.reason}` : ""}).`,
      );
      if (event.code === 4014) {
        console.error(
          "[gateway] Discord rejected a privileged intent. Enable Message Content Intent in the Developer Portal.",
        );
      }
      if (!this.stopping) this.scheduleReconnect();
    });
    socket.addEventListener("error", () => {
      console.error("[gateway] WebSocket connection error.");
    });
  }

  private async handlePayload(payload: GatewayPayload): Promise<void> {
    if (payload.op === 10) {
      this.heartbeatInterval = payload.d?.heartbeat_interval ?? 0;
      this.startHeartbeats();
      if (this.sessionId && this.sequence !== null) {
        this.send({
          op: 6,
          d: { token: this.token, session_id: this.sessionId, seq: this.sequence },
        });
      } else {
        this.send({
          op: 2,
          d: {
            token: this.token,
            intents: INTENTS,
            properties: { os: process.platform, browser: "pokemon-card-bot", device: "pokemon-card-bot" },
          },
        });
      }
      return;
    }
    if (payload.op === 1) {
      this.sendHeartbeat();
      return;
    }
    if (payload.op === 7) {
      this.socket?.close(4000, "Gateway requested reconnect");
      return;
    }
    if (payload.op === 9) {
      const resumable = Boolean(payload.d);
      if (!resumable) {
        this.sessionId = undefined;
        this.sequence = null;
        this.resumeUrl = undefined;
      }
      await sleep(1_500);
      this.socket?.close(4000, "Invalid session");
      return;
    }
    if (payload.op === 11) {
      this.heartbeatAcknowledged = true;
      return;
    }
    if (payload.op !== 0) return;

    if (payload.t === "READY") {
      this.sessionId = payload.d?.session_id;
      this.resumeUrl = payload.d?.resume_gateway_url;
      if (this.applicationId && payload.d?.application?.id) {
        this.applicationId = payload.d.application.id;
      }
      console.info(`[gateway] Connected as ${payload.d?.user?.username ?? "Discord bot"}.`);
      this.readyResolver?.();
    } else if (payload.t === "INTERACTION_CREATE") {
      void this.commands.handle(payload.d as DiscordInteraction).catch((error) => {
        console.error(`[gateway] Interaction handling failed: ${(error as Error).message}`);
      });
    }
  }

  private startHeartbeats(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    if (!this.heartbeatInterval) return;
    this.heartbeatAcknowledged = true;
    this.heartbeatTimer = setInterval(() => {
      if (!this.heartbeatAcknowledged) {
        this.socket?.close(4000, "Missed heartbeat acknowledgement");
        return;
      }
      this.sendHeartbeat();
    }, this.heartbeatInterval);
  }

  private sendHeartbeat(): void {
    this.heartbeatAcknowledged = false;
    this.send({ op: 1, d: this.sequence });
  }

  private send(payload: unknown): void {
    if (this.socket?.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(payload));
    }
  }

  private scheduleReconnect(): void {
    if (this.stopping || this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = undefined;
      this.openSocket(this.resumeUrl ?? this.gatewayUrl);
    }, 3_000);
  }
}

function decodeApplicationId(token: string): string | undefined {
  const firstPart = token.split(".")[0];
  if (!firstPart) return undefined;
  try {
    return Buffer.from(firstPart, "base64url").toString("utf8");
  } catch {
    return undefined;
  }
}

function sleep(milliseconds: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}