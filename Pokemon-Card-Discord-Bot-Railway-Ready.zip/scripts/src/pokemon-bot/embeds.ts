import type { DiscordEmbed, PokemonCard, PokemonSet, PriceChartingPrice, PriceSnapshot } from "./types.js";
import { truncate } from "./discord-rest.js";

export function makeCardEmbed(
  card: PokemonCard,
  set: PokemonSet,
  price: PriceChartingPrice | undefined,
  history: PriceSnapshot[] = [],
  relatedLinks: string[] = [],
): DiscordEmbed {
  const details = [
    card.category ? `**Category:** ${card.category}` : "",
    card.hp !== undefined ? `**HP:** ${card.hp}` : "",
    card.types?.length ? `**Type:** ${card.types.join(", ")}` : "",
    card.stage ? `**Stage:** ${card.stage}` : "",
    card.evolveFrom ? `**Evolves from:** ${card.evolveFrom}` : "",
    card.evolveTo?.length ? `**Evolves to:** ${card.evolveTo.join(", ")}` : "",
    card.trainerType ? `**Trainer type:** ${card.trainerType}` : "",
    card.rarity ? `**Rarity:** ${card.rarity}` : "",
    card.illustrator ? `**Illustrator:** ${card.illustrator}` : "",
    card.regulationMark ? `**Regulation mark:** ${card.regulationMark}` : "",
    card.dexId?.length ? `**Pokédex:** ${card.dexId.join(", ")}` : "",
    card.description ? `**Text:** ${card.description}` : "",
    card.effect ? `**Effect:** ${card.effect}` : "",
    card.variants
      ? `**Prints:** ${Object.entries(card.variants)
          .filter(([, available]) => available)
          .map(([variant]) => variant)
          .join(", ")}`
      : "",
  ].filter(Boolean);

  const abilityLines = (card.abilities ?? []).map((ability) =>
    [ability.type, ability.name, ability.effect].filter(Boolean).join(": "),
  );
  const attackLines = (card.attacks ?? []).map((attack) => {
    const cost = attack.cost?.length ? ` [${attack.cost.join(", ")}]` : "";
    const damage = attack.damage !== undefined ? ` — ${attack.damage}` : "";
    return `**${attack.name ?? "Attack"}**${cost}${damage}${attack.effect ? `\n${attack.effect}` : ""}`;
  });
  const defenses = [
    ...(card.weaknesses ?? []).map((item) => `Weakness ${item.type ?? ""} ${item.value ?? ""}`.trim()),
    ...(card.resistances ?? []).map((item) => `Resistance ${item.type ?? ""} ${item.value ?? ""}`.trim()),
    card.retreat !== undefined ? `Retreat ${card.retreat}` : "",
  ].filter(Boolean);

  const observedAverage = mean(history.map((item) => item.ungradedPrice));
  const priceLines = price?.ungradedPrice !== undefined
    ? [
        `Ungraded value: **${money(price.ungradedPrice, price.currency)}**`,
        observedAverage !== undefined
          ? `30-day observed average: **${money(observedAverage, price.currency)}**`
          : "",
        "PriceCharting ungraded price estimate.",
      ].filter(Boolean)
    : price
      ? ["PriceCharting found this card, but no ungraded value is currently listed."]
      : [
          "PriceCharting pricing is unavailable for this card.",
          "A matching PriceCharting product and API access are required.",
        ];

  const title = truncate(`${card.name} · ${card.localId}`, 256);
  const description = `**Set:** ${set.name}\n**Language:** ${languageName(set.language)}`;
  const footer = `TCGdex • set:${set.language}:${set.id} • price source: PriceCharting`;
  const fields = fitFields(
    [
    { name: "Card details", value: details.join("\n") || "No additional card details." },
    ...(abilityLines.length
      ? [{ name: "Abilities", value: abilityLines.join("\n\n") }]
      : []),
    ...(attackLines.length ? [{ name: "Attacks", value: attackLines.join("\n\n") }] : []),
    ...(defenses.length
      ? [{ name: "Weakness, resistance & retreat", value: defenses.join(" · ") }]
      : []),
    { name: "PriceCharting pricing (USD)", value: priceLines.join("\n") },
    ...(relatedLinks.length
      ? [{ name: "Matching cards in other channels", value: relatedLinks.join("\n") }]
      : []),
    ],
    title.length + description.length + footer.length,
  );

  return {
    title,
    description,
    color: 0xe6b422,
    fields: fields.slice(0, 25),
    ...(card.image
      ? { image: { url: card.image.match(/\.(png|jpe?g|webp)(\?.*)?$/i) ? card.image : `${card.image}/high.webp` } }
      : {}),
    footer: { text: footer },
  };
}

function fitFields(
  requested: Array<{ name: string; value: string }>,
  fixedCharacters: number,
): Array<{ name: string; value: string }> {
  let remaining = Math.max(0, 6000 - fixedCharacters);
  const fields: Array<{ name: string; value: string }> = [];
  for (const field of requested.slice(0, 25)) {
    const name = truncate(field.name, 256);
    const valueBudget = Math.min(1024, remaining - name.length);
    if (valueBudget < 1) break;
    const value = truncate(field.value, valueBudget);
    fields.push({ name, value });
    remaining -= name.length + value.length;
  }
  return fields;
}

function mean(values: Array<number | undefined>): number | undefined {
  const present = values.filter((value): value is number => value !== undefined && Number.isFinite(value));
  if (present.length === 0) return undefined;
  return present.reduce((sum, value) => sum + value, 0) / present.length;
}

function money(value: number, currency: string): string {
  return `${currency} ${value.toFixed(2)}`;
}

function languageName(language: PokemonSet["language"]): string {
  if (language === "en") return "English";
  if (language === "ja") return "Japanese";
  return language === "zh-cn" ? "Chinese (Simplified)" : "Chinese (Traditional)";
}