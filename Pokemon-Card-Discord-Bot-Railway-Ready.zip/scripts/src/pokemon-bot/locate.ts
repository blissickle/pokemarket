import type { DiscordEmbed, DiscordMessage, DiscordThread, PokemonCard, PokemonSet, PriceChartingPrice } from "./types.js";
import type { DiscordRest } from "./discord-rest.js";
import { discordMessageUrl, truncate } from "./discord-rest.js";
import { makeCardEmbed } from "./embeds.js";
import type { StateStore } from "./state.js";

type Candidate = {
  guildId: string;
  channelId: string;
  message: DiscordMessage;
  threadName?: string;
  searchableText: string;
};

export async function locateMatches(
  rest: DiscordRest,
  state: StateStore,
  guildId: string,
  name: string,
  set?: PokemonSet,
): Promise<Candidate[]> {
  const channelIds = state.snapshot().locateChannels[guildId] ?? [];
  if (channelIds.length === 0) return [];
  const candidates = await scanGuild(rest, guildId, channelIds);
  const normalizedName = normalize(name);
  return candidates.filter((candidate) => {
    if (!normalize(candidate.searchableText).includes(normalizedName)) return false;
    return !set || hasSet(candidate.searchableText, set);
  });
}

export async function autoLinkSet(
  rest: DiscordRest,
  state: StateStore,
  guildId: string,
  posts: Array<{
    post: {
      channelId: string;
      messageId: string;
      card: PokemonCard;
      setId: string;
      setName: string;
      language: PokemonSet["language"];
      priceProductId?: string;
    };
    set: PokemonSet;
    price?: PriceChartingPrice;
  }>,
): Promise<void> {
  if (posts.length === 0) return;
  const snapshot = state.snapshot();
  const configuredChannels = snapshot.locateChannels[guildId] ?? [];
  const extraChannels = posts.map((entry) => entry.post.channelId);
  const candidates = await scanGuild(rest, guildId, [...configuredChannels, ...extraChannels]);

  for (const entry of posts) {
    const current = entry.post;
    const matches = candidates.filter((candidate) => {
      if (!normalize(candidate.searchableText).includes(normalize(current.card.name))) return false;
      return (
        candidate.searchableText.includes(`set:${current.language}:${current.setId}`) ||
        normalize(candidate.searchableText).includes(normalize(current.setName))
      );
    });
    const related = matches
      .filter((candidate) => candidate.message.id !== current.messageId)
      .slice(0, 8);
    if (related.length === 0) continue;

    const relatedLinks = related.map((candidate) =>
      `[${truncate(candidate.threadName ?? candidate.message.embeds?.[0]?.title ?? "Matching post", 70)}]` +
      `(${discordMessageUrl(guildId, candidate.channelId, candidate.message.id)})`,
    );
    const tracked = state
      .snapshot()
      .trackedPosts.find((post) => post.messageId === current.messageId);
    if (tracked) {
      const original = await rest.request<DiscordMessage>(
        `/channels/${current.channelId}/messages/${current.messageId}`,
      );
      const setForEmbed: PokemonSet = {
        id: current.setId,
        name: current.setName,
        language: current.language,
      };
      const nextEmbed = makeCardEmbed(
        current.card,
        setForEmbed,
        entry.price,
        current.priceProductId
          ? state.snapshot().priceHistory[current.priceProductId] ?? []
          : [],
        relatedLinks,
      );
      const embeds = original.embeds?.length ? [nextEmbed] : [nextEmbed];
      await rest.editMessage(current.channelId, current.messageId, { embeds });
    }

    for (const candidate of related) {
      const crossLinkKey = `${candidate.message.id}:${current.messageId}`;
      if (state.hasCrossLink(crossLinkKey)) continue;
      try {
        await rest.createMessage(candidate.channelId, {
          content:
            `Another copy of **${current.card.name}** from **${current.setName}** was posted: ` +
            discordMessageUrl(guildId, current.channelId, current.messageId),
          message_reference: {
            message_id: candidate.message.id,
            channel_id: candidate.channelId,
            guild_id: guildId,
            fail_if_not_exists: false,
          },
          allowed_mentions: { parse: [] },
        });
        await state.markCrossLink(crossLinkKey);
      } catch (error) {
        console.warn(`[locate] Could not reply with a cross-link: ${(error as Error).message}`);
      }
    }
  }
}

async function scanGuild(
  rest: DiscordRest,
  guildId: string,
  requestedChannels: string[],
): Promise<Candidate[]> {
  const parents = [...new Set(requestedChannels)];
  const candidates: Candidate[] = [];
  const threadChannels = new Map<string, string>();

  for (const parentId of parents) {
    try {
      const channel = await rest.channel(parentId);
      if (channel.type === 11 || channel.type === 12) {
        threadChannels.set(channel.id, channel.name ?? "Thread");
        continue;
      }
      if (channel.type !== 15) {
        const messages = await listMessages(rest, parentId, 5);
        for (const message of messages) {
          candidates.push(makeCandidate(guildId, parentId, message));
        }
      }

      const archived = await listArchivedThreads(rest, parentId);
      for (const thread of archived) threadChannels.set(thread.id, thread.name ?? "Archived thread");
    } catch (error) {
      console.warn(`[locate] Could not read configured channel ${parentId}: ${(error as Error).message}`);
    }
  }

  try {
    const active = await rest.request<{ threads?: DiscordThread[] }>(
      `/guilds/${guildId}/threads/active`,
    );
    const parentSet = new Set(parents);
    for (const thread of active.threads ?? []) {
      if (thread.parent_id && parentSet.has(thread.parent_id)) {
        threadChannels.set(thread.id, thread.name ?? "Thread");
      }
    }
  } catch (error) {
    console.warn(`[locate] Could not list active threads: ${(error as Error).message}`);
  }

  for (const [threadId, threadName] of threadChannels) {
    try {
      const messages = await listMessages(rest, threadId, 10);
      for (const message of messages) {
        candidates.push(makeCandidate(guildId, threadId, message, threadName));
      }
    } catch (error) {
      console.warn(`[locate] Could not read thread ${threadId}: ${(error as Error).message}`);
    }
  }
  return candidates;
}

async function listMessages(
  rest: DiscordRest,
  channelId: string,
  maxPages: number,
): Promise<DiscordMessage[]> {
  const output: DiscordMessage[] = [];
  let before: string | undefined;
  for (let page = 0; page < maxPages; page++) {
    const query = new URLSearchParams({ limit: "100" });
    if (before) query.set("before", before);
    const messages = await rest.request<DiscordMessage[]>(
      `/channels/${channelId}/messages?${query.toString()}`,
    );
    if (messages.length === 0) break;
    output.push(...messages);
    before = messages[messages.length - 1]?.id;
    if (messages.length < 100 || !before) break;
  }
  return output;
}

async function listArchivedThreads(rest: DiscordRest, parentId: string): Promise<DiscordThread[]> {
  const output: DiscordThread[] = [];
  let before: string | undefined;
  for (let page = 0; page < 20; page++) {
    const query = new URLSearchParams({ limit: "100" });
    if (before) query.set("before", before);
    try {
      const result = await rest.request<{ threads?: DiscordThread[]; has_more?: boolean }>(
        `/channels/${parentId}/threads/archived/public?${query.toString()}`,
      );
      const threads = result.threads ?? [];
      output.push(...threads);
      if (!result.has_more || threads.length === 0) break;
      before = threads[threads.length - 1]?.thread_metadata?.archive_timestamp;
      if (!before) break;
    } catch {
      break;
    }
  }
  return output;
}

function makeCandidate(
  guildId: string,
  channelId: string,
  message: DiscordMessage,
  threadName?: string,
): Candidate {
  const embedText = (message.embeds ?? [])
    .flatMap((embed) => [
      embed.title,
      embed.description,
      embed.footer?.text,
      ...(embed.fields ?? []).flatMap((field) => [field.name, field.value]),
    ])
    .filter(Boolean)
    .join("\n");
  return {
    guildId,
    channelId,
    message,
    threadName,
    searchableText: [threadName, message.content, embedText].filter(Boolean).join("\n"),
  };
}

function hasSet(text: string, set: PokemonSet): boolean {
  const normalized = normalize(text);
  const tokens = new Set(normalized.split(" "));
  const normalizedId = normalize(set.id);
  return (
    normalized.includes(normalize(`set:${set.language}:${set.id}`)) ||
    tokens.has(normalizedId) ||
    normalized.includes(normalize(set.name))
  );
}

function normalize(value: string): string {
  return value
    .normalize("NFKD")
    .replace(/\p{Diacritic}/gu, "")
    .toLocaleLowerCase()
    .replace(/[^\p{Letter}\p{Number}]+/gu, " ")
    .trim()
    .replace(/\s+/g, " ");
}