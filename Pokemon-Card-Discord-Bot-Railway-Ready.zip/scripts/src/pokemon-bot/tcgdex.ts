import type { CardSummary, LanguageCode, PokemonCard, PokemonSet } from "./types.js";

const API_ROOT = "https://api.tcgdex.net/v2";
const languageLabels: Record<LanguageCode, string> = {
  en: "English",
  ja: "Japanese",
  "zh-cn": "Chinese",
  "zh-tw": "Chinese (Traditional)",
};

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" ? (value as Record<string, unknown>) : {};
}

async function fetchJson<T>(url: string): Promise<T> {
  const response = await fetch(url, {
    headers: { accept: "application/json", "user-agent": "PokemonSetDiscordBot/1.0" },
    signal: AbortSignal.timeout(20_000),
  });
  if (!response.ok) {
    throw new Error(`TCGdex returned HTTP ${response.status} for ${new URL(url).pathname}`);
  }
  return (await response.json()) as T;
}

export class TCGdexClient {
  private setCache = new Map<LanguageCode, { expiresAt: number; sets: PokemonSet[] }>();

  async listSets(language: LanguageCode): Promise<PokemonSet[]> {
    const cached = this.setCache.get(language);
    if (cached && cached.expiresAt > Date.now()) return cached.sets;

    const raw = await fetchJson<unknown[]>(`${API_ROOT}/${language}/sets`);
    const sets: PokemonSet[] = raw.flatMap((value) => {
        const item = asRecord(value);
        if (typeof item.id !== "string" || typeof item.name !== "string") return [];
        return [{
          id: item.id,
          name: item.name,
          language,
          cardCount: item.cardCount as PokemonSet["cardCount"],
        } satisfies PokemonSet];
      });

    this.setCache.set(language, { expiresAt: Date.now() + 60 * 60 * 1000, sets });
    return sets;
  }

  async getSet(language: LanguageCode, setId: string): Promise<{ set: PokemonSet; cards: PokemonCard[] }> {
    const raw = asRecord(
      await fetchJson<unknown>(`${API_ROOT}/${language}/sets/${encodeURIComponent(setId)}`),
    );
    if (typeof raw.id !== "string" || typeof raw.name !== "string") {
      throw new Error("TCGdex returned an invalid set.");
    }

    const set: PokemonSet = {
      id: raw.id,
      name: raw.name,
      language,
      cardCount: raw.cardCount as PokemonSet["cardCount"],
    };
    const summaries = Array.isArray(raw.cards)
      ? (raw.cards as unknown[])
          .map((item) => {
            const card = asRecord(item);
            if (
              typeof card.id !== "string" ||
              typeof card.name !== "string" ||
              typeof card.localId !== "string"
            ) {
              return null;
            }
            return { id: card.id, name: card.name, localId: card.localId } satisfies CardSummary;
          })
          .filter((card): card is CardSummary => Boolean(card))
      : [];

    if (summaries.length === 0) {
      throw new Error(`TCGdex did not list any cards for ${set.name}.`);
    }

    const cards = await mapWithConcurrency(summaries, 6, async (summary) => {
      const detail = asRecord(
        await fetchJson<unknown>(`${API_ROOT}/${language}/cards/${encodeURIComponent(summary.id)}`),
      );
      return {
        ...summary,
        ...detail,
        id: summary.id,
        localId: summary.localId,
        name: typeof detail.name === "string" ? detail.name : summary.name,
      } as PokemonCard;
    });

    if (language !== "en") {
      try {
        const englishRaw = asRecord(
          await fetchJson<unknown>(
            `${API_ROOT}/en/sets/${encodeURIComponent(setId.toLowerCase())}`,
          ),
        );
        if (typeof englishRaw.name === "string") set.englishName = englishRaw.name;
        if (Array.isArray(englishRaw.cards)) {
          const namesByNumber = new Map<string, string>();
          for (const entry of englishRaw.cards) {
            const card = asRecord(entry);
            if (typeof card.localId === "string" && typeof card.name === "string") {
              namesByNumber.set(card.localId, card.name);
            }
          }
          for (const card of cards) {
            card.englishName = namesByNumber.get(card.localId);
          }
        }
      } catch {
        // Chinese releases do not always have a one-to-one English set or card number.
      }
    }

    return { set, cards };
  }

  autocompleteLabel(language: LanguageCode, setName: string): string {
    return `${languageLabels[language]} | ${setName}`.slice(0, 100);
  }
}

async function mapWithConcurrency<T, R>(
  values: T[],
  concurrency: number,
  mapper: (value: T) => Promise<R>,
): Promise<R[]> {
  const output = new Array<R>(values.length);
  let nextIndex = 0;
  const workers = Array.from({ length: Math.min(concurrency, values.length) }, async () => {
    while (true) {
      const index = nextIndex++;
      if (index >= values.length) return;
      output[index] = await mapper(values[index]);
    }
  });
  await Promise.all(workers);
  return output;
}

export function parseSetChoice(value: string): { language: LanguageCode; setId: string } | null {
  const separator = value.indexOf(":");
  if (separator < 1) return null;
  const language = value.slice(0, separator) as LanguageCode;
  const setId = value.slice(separator + 1);
  if (!["en", "ja", "zh-cn", "zh-tw"].includes(language) || !setId) return null;
  return { language, setId };
}