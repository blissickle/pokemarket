export type LanguageCode = "en" | "ja" | "zh-cn" | "zh-tw";

export type PokemonSet = {
  id: string;
  name: string;
  language: LanguageCode;
  englishName?: string;
  cardCount?: { total?: number; official?: number };
};

export type CardSummary = {
  id: string;
  name: string;
  localId: string;
};

export type PokemonCard = {
  id: string;
  localId: string;
  name: string;
  image?: string;
  category?: string;
  hp?: number | string;
  types?: string[];
  stage?: string;
  evolveFrom?: string;
  evolveTo?: string[];
  dexId?: number[];
  regulationMark?: string;
  rarity?: string;
  illustrator?: string;
  effect?: string;
  variants?: Record<string, boolean>;
  abilities?: Array<{ type?: string; name?: string; effect?: string }>;
  attacks?: Array<{
    name?: string;
    cost?: string[];
    damage?: string | number;
    effect?: string;
  }>;
  weaknesses?: Array<{ type?: string; value?: string }>;
  resistances?: Array<{ type?: string; value?: string }>;
  retreat?: number;
  trainerType?: string;
  description?: string;
  englishName?: string;
};

export type PriceChartingPrice = {
  productId: string;
  currency: "USD";
  ungradedPrice?: number;
  productName?: string;
  consoleName?: string;
};

export type TrackedPost = {
  guildId: string;
  language: LanguageCode;
  setId: string;
  setName: string;
  card: PokemonCard;
  parentChannelId: string;
  channelId: string;
  messageId: string;
  priceProductId?: string;
  lastPriceLookupAt?: number;
  forumPost: boolean;
};

export type PriceSnapshot = {
  at: number;
  ungradedPrice?: number;
};

export type BotState = {
  locateChannels: Record<string, string[]>;
  trackedPosts: TrackedPost[];
  priceHistory: Record<string, PriceSnapshot[]>;
  postedCrossLinks: string[];
};

export type DiscordChannel = {
  id: string;
  guild_id?: string;
  type: number;
  parent_id?: string;
  name?: string;
};

export type DiscordEmbed = {
  title?: string;
  description?: string;
  url?: string;
  color?: number;
  fields?: Array<{ name: string; value: string; inline?: boolean }>;
  image?: { url: string };
  footer?: { text: string };
};

export type DiscordMessage = {
  id: string;
  channel_id: string;
  guild_id?: string;
  author?: { id: string; bot?: boolean; username?: string };
  content?: string;
  embeds?: DiscordEmbed[];
  thread?: DiscordChannel;
};

export type DiscordThread = DiscordChannel & {
  message?: DiscordMessage;
  thread_metadata?: { archive_timestamp?: string; archived?: boolean };
};

export type DiscordInteraction = {
  id: string;
  application_id: string;
  token: string;
  type: number;
  guild_id?: string;
  channel_id?: string;
  member?: { permissions?: string; user?: { id: string } };
  user?: { id: string };
  data?: {
    name?: string;
    custom_id?: string;
    component_type?: number;
    values?: string[];
    options?: Array<{
      name: string;
      type: number;
      value?: string;
      focused?: boolean;
      options?: Array<{ name: string; type: number; value?: string }>;
    }>;
  };
};