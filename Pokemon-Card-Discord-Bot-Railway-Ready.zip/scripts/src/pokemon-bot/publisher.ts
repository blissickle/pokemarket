import { DiscordRest, truncate } from "./discord-rest.js";
import { makeCardEmbed } from "./embeds.js";
import { autoLinkSet } from "./locate.js";
import type { StateStore } from "./state.js";
import type { PriceChartingClient } from "./pricecharting.js";
import type {
  DiscordChannel,
  LanguageCode,
  PokemonCard,
  PokemonSet,
  PriceChartingPrice,
  TrackedPost,
} from "./types.js";

const FORUM_CHANNEL = 15;

export type PublishedCard = {
  post: TrackedPost;
  set: PokemonSet;
  price?: PriceChartingPrice;
};

export class SetPublisher {
  constructor(
    private readonly rest: DiscordRest,
    private readonly state: StateStore,
    private readonly market: PriceChartingClient,
  ) {}

  async publish(
    guildId: string,
    destinationId: string,
    set: PokemonSet,
    cards: PokemonCard[],
    onProgress: (completed: number, total: number) => Promise<void>,
  ): Promise<number> {
    const destination: DiscordChannel = await this.rest.channel(destinationId);
    if (destination.guild_id !== guildId || ![0, FORUM_CHANNEL].includes(destination.type)) {
      throw new Error("Choose a text or forum channel in this server.");
    }

    const prices = await this.market.pricesForSet(set, cards);
    let textThreadId: string | undefined;
    if (destination.type !== FORUM_CHANNEL) {
      const thread = await this.rest.createThread(destinationId, {
        name: truncate(`${set.name} · ${languageLabel(set.language)}`, 100),
        auto_archive_duration: 1440,
        type: 11,
      });
      textThreadId = thread.id;
      await this.rest.createMessage(textThreadId, {
        content: `Card list for **${set.name}** (${languageLabel(set.language)}). ` +
          "Prices refresh daily when PriceCharting data is available.",
        allowed_mentions: { parse: [] },
      });
    }

    const published: PublishedCard[] = [];
    for (let index = 0; index < cards.length; index++) {
      const card = cards[index];
      const price = prices.get(card.id);
      const embed = makeCardEmbed(card, set, price);
      let threadId: string;
      let messageId: string;
      const forumPost = destination.type === FORUM_CHANNEL;

      if (forumPost) {
        const post = await this.rest.createThread(destinationId, {
          name: truncate(`${card.name} · ${card.localId}`, 100),
          auto_archive_duration: 10080,
          message: { embeds: [embed], allowed_mentions: { parse: [] } },
        });
        threadId = post.id;
        if (post.message?.id) {
          messageId = post.message.id;
        } else {
          const messages = await this.rest.request<Array<{ id: string }>>(
            `/channels/${post.id}/messages?limit=1`,
          );
          if (!messages[0]?.id) throw new Error(`Could not locate the first forum post for ${card.name}.`);
          messageId = messages[0].id;
        }
      } else {
        threadId = textThreadId!;
        const message = await this.rest.createMessage(threadId, {
          embeds: [embed],
          allowed_mentions: { parse: [] },
        });
        messageId = message.id;
      }

      const tracked: TrackedPost = {
        guildId,
        language: set.language,
        setId: set.id,
        setName: set.name,
        card,
        parentChannelId: destinationId,
        channelId: threadId,
        messageId,
        priceProductId: price?.productId,
        ...(this.market.hasVerifiedAccess ? { lastPriceLookupAt: Date.now() } : {}),
        forumPost,
      };
      const entry: PublishedCard = { post: tracked, set, price };
      published.push(entry);
      await this.state.addTrackedPosts([tracked]);
      if (price?.productId) {
        if (price.ungradedPrice !== undefined) {
          await this.state.recordSnapshot(price.productId, {
            at: Date.now(),
            ungradedPrice: price.ungradedPrice,
          });
        }
      }

      if ((index + 1) % 10 === 0 || index + 1 === cards.length) {
        await onProgress(index + 1, cards.length);
      }
    }

    try {
      await autoLinkSet(this.rest, this.state, guildId, published);
    } catch (error) {
      console.warn(`[locate] Could not finish automatic card linking: ${(error as Error).message}`);
    }
    return published.length;
  }
}

function languageLabel(language: LanguageCode): string {
  if (language === "en") return "English";
  if (language === "ja") return "Japanese";
  return language === "zh-cn" ? "Chinese" : "Chinese (Traditional)";
}