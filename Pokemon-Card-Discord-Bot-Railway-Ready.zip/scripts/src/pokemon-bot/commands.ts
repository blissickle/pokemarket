import { DiscordRest, discordMessageUrl, truncate } from "./discord-rest.js";
import { locateMatches } from "./locate.js";
import { SetPublisher } from "./publisher.js";
import type { PriceChartingClient } from "./pricecharting.js";
import type { StateStore } from "./state.js";
import { parseSetChoice, TCGdexClient } from "./tcgdex.js";
import type { DiscordInteraction, LanguageCode, PokemonSet } from "./types.js";

const LANGUAGES: LanguageCode[] = ["en", "ja", "zh-cn", "zh-tw"];
const CHANNEL_TYPES = [0, 15];
const EPHEMERAL = 64;
const SET_LABEL_OVERRIDES: Record<string, string> = {
  "zh-cn:sv10": "Glory for Team Rocket",
  "zh-tw:sv10": "Glory for Team Rocket",
};

export class BotCommands {
  private readonly publisher: SetPublisher;

  constructor(
    private readonly rest: DiscordRest,
    private readonly catalog: TCGdexClient,
    private readonly state: StateStore,
    market: PriceChartingClient,
  ) {
    this.publisher = new SetPublisher(rest, state, market);
  }

  async handle(interaction: DiscordInteraction): Promise<void> {
    if (interaction.type === 4) {
      await this.handleAutocomplete(interaction);
      return;
    }
    if (interaction.type === 3) {
      await this.handleDestinationSelect(interaction);
      return;
    }
    if (interaction.type !== 2 || !interaction.data?.name) return;

    try {
      if (interaction.data.name === "set") {
        await this.handleSet(interaction);
      } else if (interaction.data.name === "locate") {
        await this.handleLocate(interaction);
      } else if (interaction.data.name === "locaterange") {
        await this.handleLocateRange(interaction);
      } else {
        await this.reply(interaction, `Unknown command: ${interaction.data.name}`);
      }
    } catch (error) {
      console.error(`[commands] ${interaction.data.name} failed: ${(error as Error).message}`);
      await this.reply(interaction, `Could not complete the command: ${(error as Error).message}`);
    }
  }

  private async handleAutocomplete(interaction: DiscordInteraction): Promise<void> {
    const focused = interaction.data?.options?.find((option) => option.focused);
    if (!focused || !["set", "locate"].includes(focused.name)) {
      await this.rest.respond(interaction.id, interaction.token, { type: 8, data: { choices: [] } });
      return;
    }
    const query = String(focused.value ?? "").toLocaleLowerCase();
    const setLists = await Promise.all(
      LANGUAGES.map(async (language) => {
        try {
          return { language, sets: await this.catalog.listSets(language) };
        } catch (error) {
          console.warn(`[tcgdex] Could not load ${language} autocomplete sets: ${(error as Error).message}`);
          return { language, sets: [] };
        }
      }),
    );
    const englishNames = new Map(
      (setLists.find((item) => item.language === "en")?.sets ?? []).map((set) => [
        set.id.toLocaleLowerCase(),
        set.name,
      ]),
    );

    const choices = setLists
      .flatMap(({ language, sets }) =>
        sets.map((set) => {
          const englishName =
            language === "en" ? set.name : englishNames.get(set.id.toLocaleLowerCase());
          const name = setAutocompleteLabel(language, set.id, set.name, englishName);
          return {
            name,
            value: `${language}:${set.id}`,
            search: `${name} ${language} ${set.name} ${englishName ?? ""}`.toLocaleLowerCase(),
          };
        }),
      )
      .filter((choice) => !query || choice.search.includes(query))
      .slice(0, 25)
      .map(({ name, value }) => ({ name, value }));
    await this.rest.respond(interaction.id, interaction.token, { type: 8, data: { choices } });
  }

  private async handleSet(interaction: DiscordInteraction): Promise<void> {
    if (!interaction.guild_id) {
      await this.reply(interaction, "Use `/set` inside a server.");
      return;
    }
    const selected = optionValue(interaction, "set");
    const set = selected ? await this.resolveSet(selected) : undefined;
    if (!set) {
      await this.reply(interaction, "Choose a set from the autocomplete list.");
      return;
    }

    const customId = `set-destination|${set.language}|${set.id}`;
    await this.rest.respond(interaction.id, interaction.token, {
      type: 4,
      data: {
        flags: EPHEMERAL,
        content: `Where should **${set.name}** be posted? Choose a text channel or forum.`,
        components: [
          {
            type: 1,
            components: [
              {
                type: 8,
                custom_id: customId,
                placeholder: "Select a text channel or forum",
                min_values: 1,
                max_values: 1,
                channel_types: CHANNEL_TYPES,
              },
            ],
          },
        ],
      },
    });
  }

  private async handleDestinationSelect(interaction: DiscordInteraction): Promise<void> {
    const customId = interaction.data?.custom_id ?? "";
    const parts = customId.split("|");
    if (parts[0] !== "set-destination" || parts.length < 3) return;
    const guildId = interaction.guild_id;
    const channelId = interaction.data?.values?.[0];
    const set = await this.resolveSet(`${parts[1]}:${parts.slice(2).join("|")}`);
    await this.rest.respond(interaction.id, interaction.token, { type: 6 });
    if (!guildId || !channelId || !set) {
      await this.editOriginal(interaction, "The selection expired or could not be loaded.");
      return;
    }

    try {
      const { set: fullSet, cards } = await this.catalog.getSet(set.language, set.id);
      await this.editOriginal(
        interaction,
        `Starting **${set.name}** — loading ${cards.length} cards and checking PriceCharting prices…`,
      );
      const count = await this.publisher.publish(guildId, channelId, fullSet, cards, async (completed, total) => {
        await this.editOriginal(
          interaction,
          `Posting **${set.name}**: ${completed}/${total} cards. This can take a few minutes for large sets.`,
        );
      });
      await this.editOriginal(
        interaction,
        `Posted ${count} cards from **${set.name}**. The bot linked matching cards in configured channels. ` +
          "PriceCharting prices refresh daily when a matching listing and API access are available.",
      );
    } catch (error) {
      console.error(`[publisher] Set publish failed: ${(error as Error).message}`);
      await this.editOriginal(interaction, `Could not post this set: ${(error as Error).message}`);
    }
  }

  private async handleLocate(interaction: DiscordInteraction): Promise<void> {
    if (!interaction.guild_id) {
      await this.reply(interaction, "Use `/locate` inside a server.");
      return;
    }
    const name = optionValue(interaction, "name");
    if (!name?.trim()) {
      await this.reply(interaction, "Enter a card name to locate.");
      return;
    }
    const selectedSet = optionValue(interaction, "set");
    const set = selectedSet ? await this.resolveSet(selectedSet) : undefined;
    if (selectedSet && !set) {
      await this.reply(interaction, "Choose the set from the autocomplete list.");
      return;
    }

    await this.rest.respond(interaction.id, interaction.token, {
      type: 5,
      data: { flags: EPHEMERAL },
    });
    try {
      const matches = await locateMatches(
        this.rest,
        this.state,
        interaction.guild_id,
        name,
        set,
      );
      if (matches.length === 0) {
        await this.editOriginal(
          interaction,
          "No matching cards found in the channels set by `/locateRange`. " +
            "The bot needs View Channel and Read Message History there.",
        );
        return;
      }
      const links = matches
        .slice(0, 20)
        .map((match) => {
          const title =
            match.threadName ?? match.message.embeds?.[0]?.title ?? match.message.author?.username ?? "Card post";
          return `• [${truncate(title, 80)}](${discordMessageUrl(
            interaction.guild_id!,
            match.channelId,
            match.message.id,
          )})`;
        });
      const header = `Found ${matches.length} matching card post${matches.length === 1 ? "" : "s"}:\n`;
      const visibleLinks: string[] = [];
      for (const link of links) {
        if (`${header}${visibleLinks.concat(link).join("\n")}`.length > 1800) break;
        visibleLinks.push(link);
      }
      const moreCount = matches.length - visibleLinks.length;
      const more = moreCount > 0 ? `\n…and ${moreCount} more.` : "";
      await this.editOriginal(
        interaction,
        `${header}${visibleLinks.join("\n")}${more}`,
      );
    } catch (error) {
      await this.editOriginal(interaction, `Could not search the configured channels: ${(error as Error).message}`);
    }
  }

  private async handleLocateRange(interaction: DiscordInteraction): Promise<void> {
    if (!interaction.guild_id) {
      await this.reply(interaction, "Use `/locateRange` inside a server.");
      return;
    }
    const permissions = BigInt(interaction.member?.permissions ?? "0");
    if ((permissions & 0x20n) === 0n && (permissions & 0x8n) === 0n) {
      await this.reply(interaction, "Only server managers can change the locate range.");
      return;
    }

    const subcommand = interaction.data?.options?.[0];
    if (subcommand?.name === "list") {
      const ids = this.state.snapshot().locateChannels[interaction.guild_id] ?? [];
      const channels = await Promise.all(
        ids.map(async (id) => {
          try {
            const channel = await this.rest.channel(id);
            return `• <#${channel.id}>`;
          } catch {
            return `• ${id} (not accessible)`;
          }
        }),
      );
      await this.reply(
        interaction,
        channels.length
          ? `Locate searches these channels and their public threads:\n${channels.join("\n")}`
          : "No channels selected. Use `/locateRange add` to choose channels.",
      );
      return;
    }

    const channelId = subcommand?.options?.find((option) => option.name === "channel")?.value;
    if (!channelId) {
      await this.reply(interaction, "Choose a channel.");
      return;
    }
    const channel = await this.rest.channel(String(channelId));
    if (channel.guild_id !== interaction.guild_id || !CHANNEL_TYPES.includes(channel.type)) {
      await this.reply(interaction, "Choose a text or forum channel from this server.");
      return;
    }

    if (subcommand.name === "add") {
      const added = await this.state.addLocateChannel(interaction.guild_id, channel.id);
      await this.reply(
        interaction,
        added
          ? `Added <#${channel.id}> to the locate range. The bot needs View Channel and Read Message History there.`
          : `<#${channel.id}> is already in the locate range.`,
      );
    } else if (subcommand.name === "remove") {
      const removed = await this.state.removeLocateChannel(interaction.guild_id, channel.id);
      await this.reply(
        interaction,
        removed ? `Removed <#${channel.id}> from the locate range.` : `<#${channel.id}> was not selected.`,
      );
    } else {
      await this.reply(interaction, "Unknown `/locateRange` action.");
    }
  }

  private async resolveSet(value: string): Promise<PokemonSet | undefined> {
    const parsed = parseSetChoice(value);
    if (!parsed) return undefined;
    const sets = await this.catalog.listSets(parsed.language);
    return sets.find((set) => set.id === parsed.setId);
  }

  private async reply(interaction: DiscordInteraction, content: string): Promise<void> {
    await this.rest.respond(interaction.id, interaction.token, {
      type: 4,
      data: { content: truncate(content, 1900), flags: EPHEMERAL, allowed_mentions: { parse: [] } },
    });
  }

  private async editOriginal(interaction: DiscordInteraction, content: string): Promise<void> {
    await this.rest.editOriginalResponse(interaction.application_id, interaction.token, {
      content: truncate(content, 1900),
      components: [],
      allowed_mentions: { parse: [] },
    });
  }
}

function optionValue(interaction: DiscordInteraction, name: string): string | undefined {
  return interaction.data?.options?.find((option) => option.name === name)?.value?.toString();
}

function languageLabel(language: LanguageCode): string {
  if (language === "en") return "English";
  if (language === "ja") return "Japanese";
  return language === "zh-cn" ? "Chinese" : "Chinese (Traditional)";
}

export function setAutocompleteLabel(
  language: LanguageCode,
  setId: string,
  localName: string,
  englishName?: string,
): string {
  const displayName =
    SET_LABEL_OVERRIDES[`${language}:${setId.toLocaleLowerCase()}`] ??
    (language === "en" ? localName : englishName) ??
    localName;
  return `${languageLabel(language)} | ${displayName}`.slice(0, 100);
}