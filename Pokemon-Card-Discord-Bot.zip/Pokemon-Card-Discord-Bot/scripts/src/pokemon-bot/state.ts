import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import type { BotState } from "./types.js";

const statePath = resolve(
  dirname(fileURLToPath(import.meta.url)),
  "../../data/pokemon-discord-bot-state.json",
);
const legacyStatePath = resolve(process.cwd(), "scripts/data/pokemon-discord-bot-state.json");

const emptyState = (): BotState => ({
  locateChannels: {},
  trackedPosts: [],
  priceHistory: {},
  postedCrossLinks: [],
});

export class StateStore {
  private value = emptyState();
  private saveQueue: Promise<void> = Promise.resolve();

  async load(): Promise<void> {
    let contents: string | undefined;
    let loadedLegacyState = false;
    try {
      contents = await readFile(statePath, "utf8");
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") {
        throw new Error(`Could not read bot state: ${(error as Error).message}`);
      }
      if (legacyStatePath !== statePath) {
        try {
          contents = await readFile(legacyStatePath, "utf8");
          loadedLegacyState = true;
        } catch (legacyError) {
          if ((legacyError as NodeJS.ErrnoException).code !== "ENOENT") {
            throw new Error(`Could not read legacy bot state: ${(legacyError as Error).message}`);
          }
        }
      }
    }

    if (contents === undefined) {
      this.value = emptyState();
      await this.save();
      return;
    }

    try {
      const parsed = JSON.parse(contents) as Partial<BotState>;
      this.value = {
        locateChannels: parsed.locateChannels ?? {},
        trackedPosts: parsed.trackedPosts ?? [],
        priceHistory: parsed.priceHistory ?? {},
        postedCrossLinks: parsed.postedCrossLinks ?? [],
      };
    } catch (error) {
      throw new Error(`Could not parse bot state: ${(error as Error).message}`);
    }
    if (loadedLegacyState) await this.save();
  }

  snapshot(): BotState {
    return structuredClone(this.value);
  }

  async save(): Promise<void> {
    const contents = JSON.stringify(this.value, null, 2);
    this.saveQueue = this.saveQueue
      .catch(() => undefined)
      .then(async () => {
        await mkdir(dirname(statePath), { recursive: true });
        const temporaryPath = `${statePath}.tmp`;
        await writeFile(temporaryPath, contents, "utf8");
        await rename(temporaryPath, statePath);
      });
    await this.saveQueue;
  }

  async addLocateChannel(guildId: string, channelId: string): Promise<boolean> {
    const channels = (this.value.locateChannels[guildId] ??= []);
    if (channels.includes(channelId)) return false;
    channels.push(channelId);
    await this.save();
    return true;
  }

  async removeLocateChannel(guildId: string, channelId: string): Promise<boolean> {
    const channels = this.value.locateChannels[guildId] ?? [];
    const next = channels.filter((id) => id !== channelId);
    if (next.length === channels.length) return false;
    this.value.locateChannels[guildId] = next;
    await this.save();
    return true;
  }

  async addTrackedPosts(posts: BotState["trackedPosts"]): Promise<void> {
    this.value.trackedPosts.push(...posts);
    await this.save();
  }

  async recordPriceLookups(
    lookups: Array<{ messageId: string; attemptedAt: number; productId?: string }>,
  ): Promise<void> {
    const trackedByMessage = new Map(
      this.value.trackedPosts.map((tracked) => [tracked.messageId, tracked]),
    );
    for (const lookup of lookups) {
      const tracked = trackedByMessage.get(lookup.messageId);
      if (!tracked) continue;
      tracked.lastPriceLookupAt = lookup.attemptedAt;
      if (lookup.productId) tracked.priceProductId = lookup.productId;
    }
    await this.save();
  }

  async recordSnapshot(productId: string, snapshot: BotState["priceHistory"][string][number]): Promise<void> {
    const rows = (this.value.priceHistory[productId] ??= []);
    rows.push(snapshot);
    const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
    this.value.priceHistory[productId] = rows.filter((row) => row.at >= cutoff);
    await this.save();
  }

  hasCrossLink(key: string): boolean {
    return this.value.postedCrossLinks.includes(key);
  }

  async markCrossLink(key: string): Promise<void> {
    this.value.postedCrossLinks.push(key);
    if (this.value.postedCrossLinks.length > 20_000) {
      this.value.postedCrossLinks.splice(0, this.value.postedCrossLinks.length - 20_000);
    }
    await this.save();
  }
}