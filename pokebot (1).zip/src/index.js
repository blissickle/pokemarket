require("dotenv").config();

const {
  Client, GatewayIntentBits, Partials, Events, REST, Routes,
  SlashCommandBuilder, PermissionFlagsBits, ChannelType,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder, ModalBuilder, TextInputBuilder,
  TextInputStyle, EmbedBuilder, ChannelSelectMenuBuilder, RoleSelectMenuBuilder
} = require("discord.js");
const Database = require("better-sqlite3");
const fs = require("fs");

const dbPath = process.env.DATABASE_PATH || "./data/pokebot.sqlite";
fs.mkdirSync(require("path").dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS settings (
  guild_id TEXT NOT NULL,
  key TEXT NOT NULL,
  value TEXT,
  PRIMARY KEY(guild_id,key)
);
CREATE TABLE IF NOT EXISTS languages (
  guild_id TEXT NOT NULL,
  language TEXT NOT NULL,
  forum_id TEXT NOT NULL,
  PRIMARY KEY(guild_id,language)
);
CREATE TABLE IF NOT EXISTS sets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  language TEXT NOT NULL,
  set_name TEXT NOT NULL,
  english_name TEXT,
  set_code TEXT,
  set_number TEXT,
  forum_thread_id TEXT,
  UNIQUE(guild_id,language,set_name)
);
CREATE TABLE IF NOT EXISTS cards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  set_id INTEGER NOT NULL,
  number TEXT NOT NULL,
  name TEXT NOT NULL,
  english_name TEXT,
  rarity TEXT,
  UNIQUE(set_id,number)
);
CREATE TABLE IF NOT EXISTS listings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  thread_id TEXT UNIQUE,
  seller_id TEXT,
  card_id INTEGER,
  title TEXT,
  url TEXT,
  created_at INTEGER
);
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  type TEXT NOT NULL,
  thread_id TEXT,
  listing_id INTEGER,
  seller_id TEXT,
  buyer_id TEXT,
  price INTEGER,
  status TEXT NOT NULL,
  created_at INTEGER
);
CREATE TABLE IF NOT EXISTS bids (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  auction_thread_id TEXT NOT NULL,
  bidder_id TEXT NOT NULL,
  amount INTEGER NOT NULL,
  created_at INTEGER
);
CREATE TABLE IF NOT EXISTS tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  channel_id TEXT UNIQUE,
  opener_id TEXT,
  type TEXT,
  created_at INTEGER
);
`);

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel]
});

const LANG_FLAGS = {
  English:"🇬🇧", Japanese:"🇯🇵", Korean:"🇰🇷",
  Chinese:"🇨🇳", "Traditional Chinese":"🇹🇼",
  French:"🇫🇷", German:"🇩🇪", Italian:"🇮🇹",
  Spanish:"🇪🇸", Portuguese:"🇵🇹"
};

function getSetting(guildId,key) {
  return db.prepare("SELECT value FROM settings WHERE guild_id=? AND key=?").get(guildId,key)?.value;
}
function setSetting(guildId,key,value) {
  db.prepare("INSERT INTO settings(guild_id,key,value) VALUES(?,?,?) ON CONFLICT(guild_id,key) DO UPDATE SET value=excluded.value")
    .run(guildId,key,String(value));
}
function roleSetting(guildId,key) {
  const id=getSetting(guildId,key);
  return id ? `<@&${id}>` : "Not configured";
}
function parseMoney(s) {
  if (!s) return null;
  const m=String(s).replace(/,/g,"").match(/(?:R|ZAR|\\$|£|€)?\\s*([0-9]+(?:\\.[0-9]{1,2})?)/i);
  return m ? Math.round(Number(m[1])) : null;
}
function field(text, names) {
  for (const n of names) {
    const re=new RegExp("^\\s*"+n.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\$&")+"\\s*[:=-]\\s*(.+)$","im");
    const m=String(text||"").match(re);
    if(m) return m[1].trim();
  }
  return null;
}
function parseListing(thread) {
  const d=thread.messageCache?.first()?.content || "";
  return {
    card: field(d,["Card","Card Name"]),
    set: field(d,["Set","Set Name"]),
    number: field(d,["Card Number","Number","Card #"]),
    language: field(d,["Language","Lang"]),
    price: parseMoney(field(d,["Price","Buy Price"]))
  };
}
async function getThreadStarter(thread) {
  try {
    return await thread.fetchStarterMessage();
  } catch { return null; }
}
async function parseThread(thread) {
  const msg=await getThreadStarter(thread);
  const content=msg?.content || "";
  return {msg, content, card:field(content,["Card","Card Name"]),set:field(content,["Set","Set Name"]),
    number:field(content,["Card Number","Number","Card #"]),language:field(content,["Language","Lang"]),
    price:parseMoney(field(content,["Price","Buy Price"])),
    starting:parseMoney(field(content,["Starting Bid","Starting Price"])),
    increment:parseMoney(field(content,["Minimum Bid","Minimum Increment","Bid Increment"])),
    buy:parseMoney(field(content,["Buy Price"])),
    ends:field(content,["Ends","End Time","Auction Ends"])}
}
function hasTag(thread,name) {
  return thread.appliedTags?.some(t=>t.name.toLowerCase()===name.toLowerCase()) || false;
}
function tagId(thread,name) {
  return thread.parent?.availableTags?.find(t=>t.name.toLowerCase()===name.toLowerCase())?.id;
}
function isForum(channel) { return channel?.type===ChannelType.GuildForum; }

async function findCard(guildId, p) {
  if (!p.card && !p.number) return null;
  let q=`SELECT c.*,s.* FROM cards c JOIN sets s ON s.id=c.set_id WHERE s.guild_id=?`;
  const args=[guildId];
  const clauses=[];
  if(p.number){clauses.push("(lower(c.number)=lower(?) OR lower(c.number)=lower(?))");args.push(p.number,p.number.split("/")[0]);}
  if(p.set){clauses.push("(lower(s.set_name) LIKE lower(?) OR lower(s.english_name) LIKE lower(?))");args.push(`%${p.set}%`,`%${p.set}%`);}
  if(p.language){clauses.push("lower(s.language)=lower(?)");args.push(p.language);}
  if(p.card){clauses.push("(lower(c.name) LIKE lower(?) OR lower(c.english_name) LIKE lower(?))");args.push(`%${p.card}%`,`%${p.card}%`);}
  if(clauses.length) q+=" AND "+clauses.join(" AND ");
  return db.prepare(q+" ORDER BY c.id LIMIT 1").get(...args);
}
async function ensureListingControls(thread, force=false) {
  if (!thread.guild || !isForum(thread.parent)) return;
  const forumId=getSetting(thread.guild.id,"marketplace_forum");
  if(forumId!==thread.parent.id) return;
  const starter=await getThreadStarter(thread);
  if(!starter) return;
  const p=await parseThread(thread);
  const card=await findCard(thread.guild.id,p);
  db.prepare(`INSERT INTO listings(guild_id,thread_id,seller_id,card_id,title,url,created_at)
    VALUES(?,?,?,?,?,?,?) ON CONFLICT(thread_id) DO UPDATE SET card_id=excluded.card_id,title=excluded.title,url=excluded.url`)
    .run(thread.guild.id,thread.id,thread.ownerId,card?.id||null,thread.name,`https://discord.com/channels/${thread.guild.id}/${thread.id}`,Date.now());

  const old=thread.messages.cache.find(m=>m.author.id===client.user.id && m.components.length);
  if(old && !force) return;
  if(old) await old.delete().catch(()=>{});
  const row=new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`buy:${thread.id}`).setLabel("Buy Now").setEmoji("🛒").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`negotiate:${thread.id}`).setLabel("Negotiate").setEmoji("💬").setStyle(ButtonStyle.Primary)
  );
  await thread.send({content:"**Marketplace Actions**",components:[row]});
}
async function ensureAuctionControls(thread) {
  if(!thread.guild || !isForum(thread.parent)) return;
  if(getSetting(thread.guild.id,"auction_forum")!==thread.parent.id) return;
  const verifiedName=getSetting(thread.guild.id,"auction_verified_tag_name")||"Verified";
  if(!hasTag(thread,verifiedName)) return;
  const starter=await getThreadStarter(thread);
  if(!starter) return;
  const liveName=getSetting(thread.guild.id,"auction_live_tag_name")||"Live";
  const live=hasTag(thread,liveName);
  const old=thread.messages.cache.find(m=>m.author.id===client.user.id && m.content==="**Auction Actions**");
  const row=new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`bid:${thread.id}`).setLabel("Place Bid").setEmoji("🔨").setStyle(ButtonStyle.Primary).setDisabled(!live),
    new ButtonBuilder().setCustomId(`bids:${thread.id}`).setLabel("View Bids").setEmoji("📋").setStyle(ButtonStyle.Secondary).setDisabled(!live)
  );
  if(old) await old.edit({components:[row]}).catch(()=>{});
  else await thread.send({content:"**Auction Actions**",components:[row]});
  const p=await parseThread(thread);
  if(p.ends && !thread._auctionTimer) {
    const end=new Date(p.ends).getTime();
    if(Number.isFinite(end) && end>Date.now()) {
      thread._auctionTimer=setTimeout(()=>finishAuction(thread.id), Math.min(end-Date.now(),2147483647));
    } else if(Number.isFinite(end) && end<=Date.now()) finishAuction(thread.id);
  }
}
async function createTransaction(guild,type,listingThread,seller,buyer,price) {
  const cat=getSetting(guild.id,"transaction_category") || getSetting(guild.id,"ticket_category");
  const overwrites=[
    {id:guild.roles.everyone.id,deny:["ViewChannel"]},
    {id:seller,allow:["ViewChannel","SendMessages","ReadMessageHistory","AttachFiles"]},
    {id:buyer,allow:["ViewChannel","SendMessages","ReadMessageHistory","AttachFiles"]},
    {id:client.user.id,allow:["ViewChannel","SendMessages","ReadMessageHistory","SendMessages","ManageChannels","ManageMessages"]}
  ];
  const ch=await guild.channels.create({
    name:`${type}-${String(listingThread.name).toLowerCase().replace(/[^a-z0-9]+/g,"-").slice(0,35)}`,
    type:ChannelType.GuildText,parent:cat||undefined,permissionOverwrites:overwrites
  });
  const tx=db.prepare(`INSERT INTO transactions(guild_id,type,thread_id,listing_id,seller_id,buyer_id,price,status,created_at)
    VALUES(?,?,?,?,?,?,?,?,?)`).run(guild.id,type,listingThread.id,
    db.prepare("SELECT id FROM listings WHERE thread_id=?").get(listingThread.id)?.id||null,
    seller,buyer,price||null,"OPEN",Date.now());
  const row=new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`middleman:${tx.lastInsertRowid}`).setLabel("Middleman").setEmoji("🤝").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`dispute:${tx.lastInsertRowid}`).setLabel("Dispute").setEmoji("⚖️").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`close_tx:${tx.lastInsertRowid}`).setLabel("Close").setStyle(ButtonStyle.Secondary)
  );
  await ch.send({content:`<@${seller}> <@${buyer}>`,embeds:[new EmbedBuilder().setTitle("Transaction Ticket").setDescription(
    `**Type:** ${type}\\n**Listing:** ${listingThread.toString()}\\n**Seller:** <@${seller}>\\n**Buyer:** <@${buyer}>\\n**Price:** ${price?`R${price}`:"Not set"}\\n**Status:** OPEN`
  )],components:[row]});
  return ch;
}
async function finishAuction(threadId) {
  const thread=await client.channels.fetch(threadId).catch(()=>null);
  if(!thread?.guild) return;
  const bids=db.prepare("SELECT * FROM bids WHERE auction_thread_id=? ORDER BY amount DESC,created_at ASC").all(threadId);
  const p=await parseThread(thread);
  const winner=bids[0];
  const tagName=getSetting(thread.guild.id,"auction_ended_tag_name")||"Ended";
  const tag=tagId(thread,tagName);
  if(tag) await thread.setAppliedTags([...thread.appliedTags.filter(id=>id!==tagId(thread,"Live")),tag]).catch(()=>{});
  const botMsg=thread.messages.cache.find(m=>m.author.id===client.user.id && m.content==="**Auction Actions**");
  if(botMsg) await botMsg.edit({components:[new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("disabled").setLabel("Auction Ended").setStyle(ButtonStyle.Secondary).setDisabled(true)
  )]}).catch(()=>{});
  if(winner) {
    const ch=await createTransaction(thread.guild,"auction",thread,thread.ownerId,winner.bidder_id,winner.amount);
    await ch.send(`🏁 Auction ended. <@${thread.ownerId}> <@${winner.bidder_id}>`);
  } else {
    await thread.send("🏁 **Auction ended with no valid bids.**");
  }
}

const commands=[
  new SlashCommandBuilder().setName("setup").setDescription("Configure PokeBot")
    .addSubcommand(s=>s.setName("cardlist").setDescription("Set a language Card List Forum")
      .addStringOption(o=>o.setName("language").setDescription("Language").setRequired(true))
      .addChannelOption(o=>o.setName("forum").setDescription("Forum channel").addChannelTypes(ChannelType.GuildForum).setRequired(true)))
    .addSubcommand(s=>s.setName("marketplace").setDescription("Set Marketplace Forum").addChannelOption(o=>o.setName("forum").setDescription("Forum").addChannelTypes(ChannelType.GuildForum).setRequired(true)))
    .addSubcommand(s=>s.setName("auction").setDescription("Set Auction Forum").addChannelOption(o=>o.setName("forum").setDescription("Forum").addChannelTypes(ChannelType.GuildForum).setRequired(true)))
    .addSubcommand(s=>s.setName("roles").setDescription("Set staff roles")
      .addRoleOption(o=>o.setName("staff").setDescription("Staff role").setRequired(true))
      .addRoleOption(o=>o.setName("middleman").setDescription("Middleman role").setRequired(true))
      .addRoleOption(o=>o.setName("dispute").setDescription("Dispute role").setRequired(true)))
    .addSubcommand(s=>s.setName("logs").setDescription("Set log channel").addChannelOption(o=>o.setName("channel").setDescription("Log channel").setRequired(true)))
    .addSubcommand(s=>s.setName("categories").setDescription("Set ticket/transaction category")
      .addChannelOption(o=>o.setName("category").setDescription("Category").addChannelTypes(ChannelType.GuildCategory).setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  new SlashCommandBuilder().setName("cardlist").setDescription("Browse the card lists")
    .addSubcommand(s=>s.setName("browse").setDescription("Browse language and sets"))
    .addSubcommand(s=>s.setName("update").setDescription("Rebuild card list posts"))
    .addSubcommand(s=>s.setName("import").setDescription("Import card list JSON").addStringOption(o=>o.setName("json").setDescription("JSON array").setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  new SlashCommandBuilder().setName("locate").setDescription("Find a marketplace card")
    .addStringOption(o=>o.setName("query").setDescription("Card name, set, number, or English name").setRequired(true)),
  new SlashCommandBuilder().setName("locate-setup").setDescription("Set the Marketplace Forum searched by /locate")
    .addChannelOption(o=>o.setName("forum").setDescription("Marketplace Forum").addChannelTypes(ChannelType.GuildForum).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  new SlashCommandBuilder().setName("auction").setDescription("Auction information")
    .addSubcommand(s=>s.setName("info").setDescription("Show auction info")),
  new SlashCommandBuilder().setName("ticket").setDescription("Create or manage ticket panels")
    .addSubcommand(s=>s.setName("create").setDescription("Create a ticket panel"))
    .addSubcommand(s=>s.setName("setup").setDescription("Set ticket category").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
      .addChannelOption(o=>o.setName("category").setDescription("Ticket category").addChannelTypes(ChannelType.GuildCategory).setRequired(true)))
    .addSubcommand(s=>s.setName("close").setDescription("Close current ticket"))
    .addSubcommand(s=>s.setName("add").setDescription("Add a user").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)))
    .addSubcommand(s=>s.setName("remove").setDescription("Remove a user").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)))
];

client.once(Events.ClientReady, async c=>{
  console.log(`Logged in as ${c.user.tag}`);
  await registerCommands();
});

async function registerCommands(){
  const rest=new REST({version:"10"}).setToken(process.env.DISCORD_TOKEN);
  const body=commands.map(c=>c.toJSON());
  const route=process.env.GUILD_ID ? Routes.applicationGuildCommands(process.env.CLIENT_ID,process.env.GUILD_ID) : Routes.applicationCommands(process.env.CLIENT_ID);
  await rest.put(route,{body});
  console.log("Commands registered.");
}

client.on(Events.ThreadCreate, async thread=>{
  if(thread.parent?.type!==ChannelType.GuildForum) return;
  await new Promise(r=>setTimeout(r,1500));
  await ensureListingControls(thread);
  await ensureAuctionControls(thread);
});
client.on(Events.ThreadUpdate, async (oldThread,newThread)=>{
  await ensureListingControls(newThread,true).catch(()=>{});
  await ensureAuctionControls(newThread).catch(()=>{});
});

client.on(Events.InteractionCreate, async i=>{
  try {
    if(i.isChatInputCommand()) return handleCommand(i);
    if(i.isStringSelectMenu()) return handleSelect(i);
    if(i.isButton()) return handleButton(i);
    if(i.isModalSubmit()) return handleModal(i);
  } catch(e) {
    console.error(e);
    if(!i.replied && !i.deferred) await i.reply({content:"Something went wrong. Check the bot console.",ephemeral:true}).catch(()=>{});
  }
});

async function handleCommand(i){
  const cmd=i.commandName;
  if(cmd==="setup"){
    if(!i.memberPermissions.has(PermissionFlagsBits.ManageGuild)) return i.reply({content:"Admin permission required.",ephemeral:true});
    const sub=i.options.getSubcommand();
    if(sub==="cardlist"){
      const lang=i.options.getString("language"), forum=i.options.getChannel("forum");
      db.prepare("INSERT INTO languages(guild_id,language,forum_id) VALUES(?,?,?) ON CONFLICT(guild_id,language) DO UPDATE SET forum_id=excluded.forum_id").run(i.guildId,lang,forum.id); setSetting(i.guildId,`forum_${lang}`,forum.id);
      return i.reply(`✅ ${lang} Card List Forum set to ${forum}.`);
    }
    if(sub==="marketplace"){setSetting(i.guildId,"marketplace_forum",i.options.getChannel("forum").id);return i.reply("✅ Marketplace Forum configured.");}
    if(sub==="auction"){setSetting(i.guildId,"auction_forum",i.options.getChannel("forum").id);return i.reply("✅ Auction Forum configured.");}
    if(sub==="roles"){setSetting(i.guildId,"staff_role",i.options.getRole("staff").id);setSetting(i.guildId,"middleman_role",i.options.getRole("middleman").id);setSetting(i.guildId,"dispute_role",i.options.getRole("dispute").id);return i.reply("✅ Staff, Middleman and Dispute roles configured.");}
    if(sub==="logs"){setSetting(i.guildId,"log_channel",i.options.getChannel("channel").id);return i.reply("✅ Log channel configured.");}
    if(sub==="categories"){setSetting(i.guildId,"ticket_category",i.options.getChannel("category").id);setSetting(i.guildId,"transaction_category",i.options.getChannel("category").id);return i.reply("✅ Ticket/transaction category configured.");}
  }

  if(cmd==="locate-setup"){
    setSetting(i.guildId,"marketplace_forum",i.options.getChannel("forum").id);
    return i.reply("✅ `/locate` will search this Marketplace Forum.");
  }

  if(cmd==="cardlist"){
    const sub=i.options.getSubcommand();
    if(sub==="browse"){
      const langs=db.prepare("SELECT language FROM languages WHERE guild_id=? ORDER BY language").all(i.guildId);
      if(!langs.length) return i.reply("No Card List languages configured. Use `/setup cardlist`.");
      const menu=new StringSelectMenuBuilder().setCustomId("cardlang").setPlaceholder("Choose a language")
        .addOptions(langs.slice(0,25).map(x=>({label:x.language,value:x.language,emoji:LANG_FLAGS[x.language]})));
      return i.reply({content:"📚 **Choose a Card List language**",components:[new ActionRowBuilder().addComponents(menu)],ephemeral:true});
    }
    if(sub==="import"){
      if(!i.memberPermissions.has(PermissionFlagsBits.ManageGuild)) return i.reply({content:"Admin permission required.",ephemeral:true});
      let data; try{data=JSON.parse(i.options.getString("json"));}catch{return i.reply({content:"Invalid JSON.",ephemeral:true});}
      const addSet=db.prepare("INSERT INTO sets(guild_id,language,set_name,english_name,set_code,set_number) VALUES(?,?,?,?,?,?) ON CONFLICT(guild_id,language,set_name) DO UPDATE SET english_name=excluded.english_name,set_code=excluded.set_code,set_number=excluded.set_number");
      const addCard=db.prepare("INSERT INTO cards(set_id,number,name,english_name,rarity) VALUES(?,?,?,?,?) ON CONFLICT(set_id,number) DO UPDATE SET name=excluded.name,english_name=excluded.english_name,rarity=excluded.rarity");
      const tx=db.transaction(items=>{for(const s of items){addSet.run(i.guildId,s.language,s.setName,s.englishName||s.setName,s.setCode||"",s.setNumber||"");const set=db.prepare("SELECT id FROM sets WHERE guild_id=? AND language=? AND set_name=?").get(i.guildId,s.language,s.setName);for(const c of s.cards||[])addCard.run(set.id,c.number,c.name,c.englishName||c.name,c.rarity||"");}});
      tx(data); return i.reply(`✅ Imported ${data.length} set(s).`);
    }
    if(sub==="update"){
      await buildCardListForums(i.guild);
      return i.reply("✅ Card List Forum posts updated.");
    }
  }

  if(cmd==="locate"){
    const q=i.options.getString("query");
    const rows=db.prepare(`SELECT l.*,c.number,c.name,c.english_name,s.set_name,s.english_name as set_english,s.language
      FROM listings l LEFT JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id WHERE l.guild_id=?`).all(i.guildId);
    const matches=rows.filter(x=>[x.name,x.english_name,x.set_name,x.set_english,x.number,x.language,x.title].some(v=>String(v||"").toLowerCase().includes(q.toLowerCase())));
    if(!matches.length)return i.reply({content:"❌ No matching marketplace listings found.",ephemeral:true});
    const embeds=matches.slice(0,10).map(x=>new EmbedBuilder().setTitle("🔎 Card Found").setDescription(
      `**Card:** ${x.name||x.title}\\n**Set:** ${x.set_name||"Unknown"}\\n**Card #:** ${x.number||"Unknown"}\\n**Language:** ${x.language||"Unknown"}${x.english_name?`\\n🇬🇧 English: **${x.english_name}**`:""}\\n\\n[🔗 View Marketplace Listing](${x.url})`
    ));
    return i.reply({embeds,ephemeral:true});
  }

  if(cmd==="auction" && i.options.getSubcommand()==="info"){
    return i.reply("Auction controls are automatically added to configured Auction Forum posts when they receive the Verified tag.");
  }

  if(cmd==="ticket"){
    const sub=i.options.getSubcommand();
    if(sub==="setup"){setSetting(i.guildId,"ticket_category",i.options.getChannel("category").id);return i.reply("✅ Ticket category configured.");}
    if(sub==="create"){
      const modal=new ModalBuilder().setCustomId("ticketpanel").setTitle("Create Ticket Panel");
      modal.addComponents(
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("name").setLabel("Ticket Name").setStyle(TextInputStyle.Short).setRequired(true)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("description").setLabel("Description").setStyle(TextInputStyle.Paragraph).setRequired(true))
      );
      return i.showModal(modal);
    }
    if(sub==="close"){
      if(!i.channel) return i.reply({content:"Not in a ticket.",ephemeral:true});
      const t=db.prepare("SELECT * FROM tickets WHERE channel_id=?").get(i.channel.id);
      if(!t)return i.reply({content:"This is not a bot ticket.",ephemeral:true});
      await i.reply("🔒 Closing ticket...");
      return i.channel.delete().catch(()=>{});
    }
    if(sub==="add"){await i.channel.permissionOverwrites.edit(i.options.getUser("user"),{ViewChannel:true,SendMessages:true,ReadMessageHistory:true});return i.reply(`✅ Added ${i.options.getUser("user")}.`);}
    if(sub==="remove"){await i.channel.permissionOverwrites.edit(i.options.getUser("user"),{ViewChannel:false});return i.reply(`✅ Removed ${i.options.getUser("user")}.`);}
  }
}

async function handleSelect(i){
  if(i.customId==="cardlang"){
    const lang=i.values[0];
    const sets=db.prepare("SELECT * FROM sets WHERE guild_id=? AND language=? ORDER BY set_name").all(i.guildId,lang);
    if(!sets.length)return i.update({content:"No sets imported for this language.",components:[]});
    const menu=new StringSelectMenuBuilder().setCustomId(`cardset:${encodeURIComponent(lang)}`).setPlaceholder("Choose a set")
      .addOptions(sets.slice(0,25).map(s=>({label:s.set_name.slice(0,100),value:String(s.id)})));
    return i.update({content:`${LANG_FLAGS[lang]||"🌎"} **${lang}** — choose a set`,components:[new ActionRowBuilder().addComponents(menu)]});
  }
  if(i.customId.startsWith("cardset:")){
    const set=db.prepare("SELECT * FROM sets WHERE id=?").get(Number(i.values[0]));
    const forum=await i.guild.channels.fetch(getSetting(i.guildId,`forum_${set.language}`)).catch(()=>null);
    const thread=set.forum_thread_id ? await i.guild.channels.fetch(set.forum_thread_id).catch(()=>null):null;
    const url=thread?`https://discord.com/channels/${i.guildId}/${thread.id}`:null;
    return i.update({content:url?`📚 **${set.set_name}**\\n🔗 [Open Set Card List](${url})`:"Set post has not been built yet. An admin should run `/cardlist update`.",components:[]});
  }
}
async function handleButton(i){
  const [action,id]=i.customId.split(":");
  if(action==="buy"||action==="negotiate"){
    const thread=await i.guild.channels.fetch(id).catch(()=>null);
    if(!thread?.parent)return i.reply({content:"Listing unavailable.",ephemeral:true});
    if(thread.ownerId===i.user.id)return i.reply({content:"You cannot buy your own listing.",ephemeral:true});
    const p=await parseThread(thread);
    const ch=await createTransaction(i.guild,action==="buy"?"buy":"negotiation",thread,thread.ownerId,i.user.id,p.price);
    return i.reply({content:`✅ Transaction ticket created: ${ch}`,ephemeral:true});
  }
  if(action==="middleman"||action==="dispute"){
    const tx=db.prepare("SELECT * FROM transactions WHERE id=?").get(Number(id));
    if(!tx)return i.reply({content:"Transaction not found.",ephemeral:true});
    const roleId=getSetting(i.guildId,action==="middleman"?"middleman_role":"dispute_role");
    if(roleId) await i.channel.permissionOverwrites.edit(roleId,{ViewChannel:true,SendMessages:true,ReadMessageHistory:true});
    if(roleId) await i.channel.send(`<@&${roleId}> — ${action==="middleman"?"🤝 Middleman requested.":"⚖️ Dispute opened."}`);
    db.prepare("UPDATE transactions SET status=? WHERE id=?").run(action==="middleman"?"MIDDLEMAN":"DISPUTE",tx.id);
    return i.reply({content:`✅ ${action==="middleman"?"Middleman":"Dispute Team"} notified.`,ephemeral:true});
  }
  if(action==="close_tx"){
    if(!i.memberPermissions.has(PermissionFlagsBits.ManageChannels))return i.reply({content:"Staff permission required.",ephemeral:true});
    await i.reply("🔒 Closing transaction...");
    return i.channel.delete().catch(()=>{});
  }
  if(action==="bid"){
    const thread=await i.guild.channels.fetch(id).catch(()=>null);
    if(!thread || !hasTag(thread,getSetting(i.guildId,"auction_live_tag_name")||"Live"))return i.reply({content:"This auction is not Live.",ephemeral:true});
    if(thread.ownerId===i.user.id)return i.reply({content:"You cannot bid on your own auction.",ephemeral:true});
    const modal=new ModalBuilder().setCustomId(`bidmodal:${id}`).setTitle("Place Bid");
    modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("amount").setLabel("Bid Amount (R)").setStyle(TextInputStyle.Short).setRequired(true)));
    return i.showModal(modal);
  }
  if(action==="bids"){
    const rows=db.prepare("SELECT bidder_id,amount,created_at FROM bids WHERE auction_thread_id=? ORDER BY amount DESC,created_at ASC LIMIT 10").all(id);
    const current=rows[0]?.amount;
    return i.reply({content:`🔨 **Auction Bids**\\nCurrent Bid: **${current?`R${current}`:"No bids"}**\\nTotal Bids: **${db.prepare("SELECT count(*) c FROM bids WHERE auction_thread_id=?").get(id).c}**\\n\\n`+
      rows.map((x,n)=>`${n+1}. <@${x.bidder_id}> — R${x.amount}`).join("\\n"),ephemeral:true});
  }
  if(action==="open_ticket"){
    const modal=new ModalBuilder().setCustomId("openticket").setTitle("Open Ticket");
    modal.addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("name").setLabel("Name").setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("description").setLabel("Description").setStyle(TextInputStyle.Paragraph).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("extra").setLabel("Additional Information").setStyle(TextInputStyle.Paragraph).setRequired(false))
    );
    return i.showModal(modal);
  }
}
async function handleModal(i){
  if(i.customId==="ticketpanel"){
    const category=getSetting(i.guildId,"ticket_category");
    const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("open_ticket").setLabel("Open Ticket").setEmoji("🎟️").setStyle(ButtonStyle.Primary));
    return i.reply({embeds:[new EmbedBuilder().setTitle(`🎟️ ${i.fields.getTextInputValue("name")}`).setDescription(i.fields.getTextInputValue("description"))],components:[row]});
  }
  if(i.customId==="openticket"){
    const category=getSetting(i.guildId,"ticket_category");
    const staff=getSetting(i.guildId,"staff_role");
    const overwrites=[
      {id:i.guild.roles.everyone.id,deny:["ViewChannel"]},
      {id:i.user.id,allow:["ViewChannel","SendMessages","ReadMessageHistory","AttachFiles"]},
      {id:client.user.id,allow:["ViewChannel","SendMessages","ReadMessageHistory","ManageChannels","ManageMessages"]}
    ];
    if(staff)overwrites.push({id:staff,allow:["ViewChannel","SendMessages","ReadMessageHistory"]});
    const ch=await i.guild.channels.create({name:`ticket-${i.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g,"").slice(0,90),type:ChannelType.GuildText,parent:category||undefined,permissionOverwrites:overwrites});
    db.prepare("INSERT INTO tickets(guild_id,channel_id,opener_id,type,created_at) VALUES(?,?,?,?,?)").run(i.guildId,ch.id,i.user.id,"support",Date.now());
    await ch.send({content:staff?`<@&${staff}> <@${i.user.id}>`:`<@${i.user.id}>`,embeds:[new EmbedBuilder().setTitle("🎟️ Support Ticket").setDescription(
      `**User:** <@${i.user.id}>\\n**Name:** ${i.fields.getTextInputValue("name")}\\n**Description:** ${i.fields.getTextInputValue("description")}\\n**Additional:** ${i.fields.getTextInputValue("extra")||"None"}\\n**Status:** Open`
    )]});
    return i.reply({content:`✅ Your ticket has been created: ${ch}`,ephemeral:true});
  }
  if(i.customId.startsWith("bidmodal:")){
    const threadId=i.customId.split(":")[1], thread=await i.guild.channels.fetch(threadId).catch(()=>null);
    if(!thread || !hasTag(thread,getSetting(i.guildId,"auction_live_tag_name")||"Live"))return i.reply({content:"Auction is no longer Live.",ephemeral:true});
    const amount=parseMoney(i.fields.getTextInputValue("amount"));
    if(!amount)return i.reply({content:"Enter a valid amount.",ephemeral:true});
    const p=await parseThread(thread);
    const top=db.prepare("SELECT max(amount) m FROM bids WHERE auction_thread_id=?").get(threadId).m;
    const minimum=top ? top+(p.increment||1) : (p.starting||0);
    if(amount<minimum)return i.reply({content:`❌ Minimum valid bid is R${minimum}.`,ephemeral:true});
    db.prepare("INSERT INTO bids(auction_thread_id,bidder_id,amount,created_at) VALUES(?,?,?,?)").run(threadId,i.user.id,amount,Date.now());
    return i.reply({content:`✅ Bid placed: **R${amount}**`,ephemeral:true});
  }
}

async function buildCardListForums(guild){
  const languages=db.prepare("SELECT * FROM languages WHERE guild_id=?").all(guild.id);
  for(const l of languages){
    const forum=await guild.channels.fetch(l.forum_id).catch(()=>null);
    if(!forum?.isThreadOnly?.()) continue;
    const sets=db.prepare("SELECT * FROM sets WHERE guild_id=? AND language=? ORDER BY set_name").all(guild.id,l.language);
    for(const s of sets){
      let thread=s.forum_thread_id ? await guild.channels.fetch(s.forum_thread_id).catch(()=>null):null;
      if(!thread){
        thread=await forum.threads.create({name:s.set_name,message:{content:`📚 **${s.set_name}**\\n\\n**Language:** ${s.language}\\n🇬🇧 **English:** ${s.english_name||s.set_name}\\n\\nCard list below. Use **/locate** to find cards in the marketplace.`}});
        db.prepare("UPDATE sets SET forum_thread_id=? WHERE id=?").run(thread.id,s.id);
      }
      const cards=db.prepare("SELECT * FROM cards WHERE set_id=? ORDER BY CAST(number AS INTEGER),number").all(s.id);
      for(const c of cards){
        const marker=`CARD:${s.id}:${c.number}`;
        const exists=thread.messages.cache.some(m=>m.content.includes(marker));
        if(!exists){
          const english=(s.language.toLowerCase()==="english" ? "" : `\\n🇬🇧 English: **${c.english_name||c.name}**`);
          await thread.send({content:`**${c.number} — ${c.name}**${english}\\n\\nSet: ${s.set_name}\\nRarity: ${c.rarity||"Unknown"}\\n\\n🔎 Use \`/locate ${c.english_name||c.name}\` to find this card in the marketplace.\\n\\n<!-- ${marker} -->`});
        }
      }
    }
  }
}

if (process.env.DEPLOY_ONLY==="1") registerCommands().then(()=>process.exit(0)).catch(e=>{console.error(e);process.exit(1);}); else client.login(process.env.DISCORD_TOKEN);
