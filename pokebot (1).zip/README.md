# PokeBot

Discord.js v14 Pokémon marketplace bot with:

- Language -> set Forum card lists
- `/cardlist` navigation
- `/locate` marketplace searching
- Automatic marketplace Buy Now / Negotiate buttons
- Buyer/seller transaction tickets
- Middleman and dispute buttons
- Auction Forum tag workflow
- Bid tracking
- Normal configurable ticket panels
- SQLite persistence

## Setup

1. Install Node.js 20+.
2. Create a Discord application/bot in the Discord Developer Portal.
3. Invite it with the `bot` and `applications.commands` scopes.
4. Give it permission to manage channels, send messages, embed links, read message history, manage threads, and mention roles as required.
5. Copy `.env.example` to `.env` and fill in:
   - `DISCORD_TOKEN`
   - `CLIENT_ID`
   - `GUILD_ID` (recommended for fast command registration)
6. Run:
   ```bash
   npm install
   npm run deploy
   npm start
   ```

## Important Discord limitation

A Forum post is a thread. Discord does not provide a reliable event specifically for "a new Forum post" separate from thread creation in every library version, so PokeBot watches `ThreadCreate` and `ThreadUpdate`.

Marketplace/Auction Forum channels must be configured with `/setup`.

For automatic marketplace parsing, use a predictable listing description such as:

```text
Card: Charizard ex
Set: Pokémon Card 151
Card Number: 006/165
Language: Japanese
Price: R500
```

Auction descriptions can contain:

```text
Card: Charizard ex
Set: Pokémon Card 151
Card Number: 006/165
Language: Japanese
Starting Bid: R500
Minimum Bid: R50
Buy Price: R1500
Ends: 2026-10-01 20:00
```

The bot also attempts to parse common variants.

## Card data

This build includes a local card/set database and an admin import command:

`/cardlist import <json>`

The JSON should be an array like:

```json
[
  {
    "language": "English",
    "setName": "Scarlet & Violet—151",
    "setCode": "MEW",
    "setNumber": "151",
    "cards": [
      {"number":"001","name":"Bulbasaur","englishName":"Bulbasaur","rarity":"Common"}
    ]
  }
]
```

This avoids hard-coding or scraping a third-party API. You can later connect the importer to any Pokémon TCG API.

## Commands

### Setup
- `/setup`
- `/setup cardlist <language> <forum>`
- `/setup marketplace <forum>`
- `/setup auction <forum>`
- `/setup tags <type> <tag>`
- `/setup roles <staff> <middleman> <dispute>`
- `/setup logs <channel>`

### Card lists
- `/cardlist`
- `/cardlist setup`
- `/cardlist update`
- `/cardlist import`

### Marketplace
- `/locate <query>`
- `/locate setup`

### Tickets
- `/ticket`
- `/ticket setup`
- `/ticket close`
- `/ticket add <user>`
- `/ticket remove <user>`

### Auctions
- `/auction info`

## Notes

The bot automatically adds marketplace controls to newly created marketplace Forum posts. The listing must have a matching card in the local database for exact `/locate` matching; the listing can still receive buttons if parsing succeeds.

Auction controls are posted when the auction has the configured `Verified` tag. The controls are enabled only while the configured `Live` tag is present. When `Live` is removed, buttons are disabled.

Auction expiration is based on the `Ends:` field in the post description. When it expires, the bot creates the winner transaction ticket.
